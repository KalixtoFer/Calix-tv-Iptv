import React, { useState, useEffect } from 'react';
import {
  X,
  Smartphone,
  Tv,
  FileCode,
  CheckCircle2,
  Terminal,
  Download,
  ExternalLink,
  Layers,
  Sparkles,
  Cpu,
  Package,
  ShieldCheck,
  Play,
  Copy,
  Check,
} from 'lucide-react';

interface ApkExportGuideModalProps {
  onClose: () => void;
}

export const ApkExportGuideModal: React.FC<ApkExportGuideModalProps> = ({ onClose }) => {
  const [copiedStep, setCopiedStep] = useState<number | null>(null);
  const [androidStatus, setAndroidStatus] = useState<{
    androidProjectReady: boolean;
    zipAvailable: boolean;
    zipSizeMb: number;
    packageId: string;
    appName: string;
  } | null>(null);

  useEffect(() => {
    fetch('/api/iptv/android-status')
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setAndroidStatus(data);
        }
      })
      .catch(console.error);
  }, []);

  const copyToClipboard = (text: string, step: number) => {
    navigator.clipboard.writeText(text);
    setCopiedStep(step);
    setTimeout(() => setCopiedStep(null), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-md animate-fadeIn select-none">
      <div className="relative w-full max-w-4xl max-h-[92vh] bg-zinc-950 border border-zinc-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-zinc-800 bg-zinc-900/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-gradient-to-tr from-emerald-600 to-teal-500 text-black font-bold rounded-2xl shadow-[0_0_15px_rgba(16,185,129,0.4)]">
              <Package className="w-5 h-5 fill-current" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-white">
                  Generador y Exportador de APK Android TV & Móvil
                </h2>
                <span className="px-2 py-0.5 bg-emerald-950 border border-emerald-700 text-emerald-400 font-mono text-[10px] font-bold rounded">
                  PROYECTO LISTO
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                Paquete nativo Android Studio configurado con soporte para control remoto y Leanback
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="tv-focusable p-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white rounded-xl transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 text-zinc-300 text-xs sm:text-sm">
          {/* Card 1: Live Status & One-Click ZIP Download */}
          <div className="p-5 bg-gradient-to-r from-emerald-950/40 via-zinc-900/90 to-teal-950/30 border-2 border-emerald-500/50 rounded-3xl shadow-[0_0_30px_rgba(16,185,129,0.15)] flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="space-y-2 text-center md:text-left">
              <div className="flex items-center justify-center md:justify-start gap-2 text-emerald-400 font-extrabold text-sm sm:text-base">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                <span>Proyecto Android Nativo Sincronizado y Compilado</span>
              </div>
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 text-xs text-zinc-400 font-mono">
                <span>ID: {androidStatus?.packageId || 'com.nexus.iptv.pro'}</span>
                <span>•</span>
                <span>Nombre: Nexus IPTV Pro</span>
                <span>•</span>
                <span>Plataforma: Android TV + Celular</span>
                {androidStatus?.zipSizeMb && (
                  <>
                    <span>•</span>
                    <span className="text-emerald-300 font-bold">{androidStatus.zipSizeMb} MB</span>
                  </>
                )}
              </div>
              <p className="text-xs text-zinc-300 max-w-lg">
                Ya incluye <strong className="text-white">AndroidManifest.xml</strong> con launcher para televisores, permisos de red para streaming en vivo y prevención de suspensión de pantalla.
              </p>
            </div>

            <a
              href="/api/iptv/download-android-zip"
              download="nexus-iptv-pro-android.zip"
              className="tv-focusable px-6 py-3.5 bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 hover:from-emerald-300 hover:to-cyan-300 text-black font-extrabold text-xs sm:text-sm rounded-2xl shadow-[0_0_25px_rgba(16,185,129,0.5)] flex items-center gap-2 cursor-pointer transition transform active:scale-95 shrink-0 whitespace-nowrap"
            >
              <Download className="w-4 h-4 stroke-[2.5]" />
              <span>DESCARGAR PROYECTO ANDROID (ZIP)</span>
            </a>
          </div>

          {/* Card 2: 3 Simple Steps to get the APK file */}
          <div className="p-5 bg-zinc-900/80 border border-zinc-800 rounded-3xl space-y-4">
            <div className="flex items-center gap-2 text-white font-bold text-sm">
              <Cpu className="w-4 h-4 text-cyan-400" />
              <span>Cómo generar el archivo .APK instalable en 3 pasos:</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {/* Step 1 */}
              <div className="p-4 bg-zinc-950/80 border border-zinc-800/80 rounded-2xl space-y-2">
                <div className="w-7 h-7 rounded-xl bg-cyan-500/20 text-cyan-400 font-mono font-bold text-xs flex items-center justify-center">
                  1
                </div>
                <h4 className="font-bold text-white text-xs sm:text-sm">Abrir en Android Studio</h4>
                <p className="text-[11px] text-zinc-400 leading-relaxed">
                  Descarga y descomprime el ZIP. En Android Studio selecciona <strong className="text-zinc-200">"Open"</strong> y elige la carpeta <strong className="text-zinc-200">android</strong>.
                </p>
              </div>

              {/* Step 2 */}
              <div className="p-4 bg-zinc-950/80 border border-zinc-800/80 rounded-2xl space-y-2">
                <div className="w-7 h-7 rounded-xl bg-purple-500/20 text-purple-400 font-mono font-bold text-xs flex items-center justify-center">
                  2
                </div>
                <h4 className="font-bold text-white text-xs sm:text-sm">Compilar APK</h4>
                <p className="text-[11px] text-zinc-400 leading-relaxed">
                  En el menú superior de Android Studio haz clic en:
                  <span className="block font-mono text-zinc-200 bg-zinc-900 p-1 rounded mt-1 text-[10px]">
                    Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)
                  </span>
                </p>
              </div>

              {/* Step 3 */}
              <div className="p-4 bg-zinc-950/80 border border-zinc-800/80 rounded-2xl space-y-2">
                <div className="w-7 h-7 rounded-xl bg-emerald-500/20 text-emerald-400 font-mono font-bold text-xs flex items-center justify-center">
                  3
                </div>
                <h4 className="font-bold text-white text-xs sm:text-sm">Instalar en TV Box o Celular</h4>
                <p className="text-[11px] text-zinc-400 leading-relaxed">
                  Android Studio generará <strong className="text-zinc-200">app-debug.apk</strong>. Cópialo a una memoria USB o instálalo con la app <strong className="text-zinc-200">Downloader</strong> en tu Firestick o TV Box.
                </p>
              </div>
            </div>
          </div>

          {/* Card 3: Cloud Build with GitHub Actions */}
          <div className="p-5 bg-zinc-900/80 border border-zinc-800 rounded-3xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <Terminal className="w-4 h-4 text-emerald-400" />
                <span>Compilación Automática en la Nube (GitHub Actions)</span>
              </div>
              <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                .github/workflows/build-apk.yml Creado
              </span>
            </div>

            <p className="text-xs text-zinc-400">
              Hemos incluido el flujo de trabajo de GitHub Actions preconfigurado. Si subes este código a un repositorio en GitHub, compilará el archivo <strong className="text-white">app-debug.apk</strong> en los servidores de GitHub de forma 100% gratuita y te entregará el link directo de descarga.
            </p>
          </div>

          {/* Card 4: Direct WebAPK / PWA installation */}
          <div className="p-5 bg-zinc-900/80 border border-zinc-800 rounded-3xl space-y-2">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
              <Tv className="w-4 h-4" />
              <span>Instalación Instantánea WebAPK (Sin Computadora)</span>
            </div>
            <p className="text-xs text-zinc-400">
              Si quieres probar la app en tu televisor de inmediato sin usar Android Studio:
            </p>
            <ol className="list-decimal list-inside space-y-1 text-xs text-zinc-300">
              <li>Abre el navegador de tu TV Box (Puffin TV, Chrome o Amazon Silk en Fire TV).</li>
              <li>Ingresa la URL de esta aplicación.</li>
              <li>Presiona en el menú del navegador la opción <strong className="text-white">"Instalar aplicación"</strong> o <strong className="text-white">"Añadir a la pantalla de inicio"</strong>.</li>
              <li>Aparecerá el ícono de Nexus IPTV Pro en la fila de aplicaciones de tu televisor.</li>
            </ol>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-zinc-900/90 border-t border-zinc-800 flex items-center justify-between">
          <span className="text-xs text-zinc-400">
            Soporte para Android 8.0 hasta Android 15 (API 26 a 35).
          </span>

          <div className="flex items-center gap-3">
            <a
              href="/api/iptv/download-android-zip"
              download="nexus-iptv-pro-android.zip"
              className="tv-focusable px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs rounded-xl shadow-md cursor-pointer transition"
            >
              Descargar ZIP
            </a>

            <button
              onClick={onClose}
              className="tv-focusable px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold rounded-xl cursor-pointer"
            >
              Cerrar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
